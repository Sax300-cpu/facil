<?php
class Departamento
{
    private PDO $conexion;

    public function __construct()
    {
        $servidor = 'localhost';
        $baseDatos = 'empresa_departamentos';
        $usuario = 'root';
        $contrasena = '';
        $dsn = "mysql:host=$servidor;dbname=$baseDatos;charset=utf8mb4";

        $this->conexion = new PDO($dsn, $usuario, $contrasena, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }

    public function obtenerDepartamentos(): array
    {
        return $this->conexion
            ->query('SELECT id, nombre FROM departamentos ORDER BY nombre')
            ->fetchAll();
    }

    public function crearDepartamento(string $nombre): void
    {
        $consulta = $this->conexion->prepare(
            'INSERT INTO departamentos (nombre) VALUES (:nombre)'
        );
        $consulta->execute(['nombre' => $nombre]);
    }

    public function existeDepartamento(int $id): bool
    {
        $consulta = $this->conexion->prepare(
            'SELECT id FROM departamentos WHERE id = :id'
        );
        $consulta->execute(['id' => $id]);
        return (bool) $consulta->fetch();
    }

    public function crearEmpleado(string $nombre, string $apellido, int $departamentoId): void
    {
        $consulta = $this->conexion->prepare(
            'INSERT INTO empleados (nombre, apellido, departamento_id)
             VALUES (:nombre, :apellido, :departamento_id)'
        );
        $consulta->execute([
            'nombre' => $nombre,
            'apellido' => $apellido,
            'departamento_id' => $departamentoId,
        ]);
    }

    public function buscarEmpleadosPorDepartamento(int $departamentoId): array
    {
        $consulta = $this->conexion->prepare(
            'SELECT e.nombre, e.apellido, d.nombre AS departamento
             FROM empleados e
             INNER JOIN departamentos d ON d.id = e.departamento_id
             WHERE d.id = :departamento_id
             ORDER BY e.apellido, e.nombre'
        );
        $consulta->execute(['departamento_id' => $departamentoId]);
        return $consulta->fetchAll();
    }
}