document.addEventListener('DOMContentLoaded', function () {
    const formularios = document.querySelectorAll('form');

    formularios.forEach(function (formulario) {
        formulario.addEventListener('submit', function (evento) {
            const accion = formulario.querySelector('input[name="accion"]');

            // El formulario de búsqueda no requiere confirmación.
            if (!accion) {
                return;
            }

            const camposTexto = formulario.querySelectorAll('input[type="text"]');
            let camposValidos = true;

            camposTexto.forEach(function (campo) {
                campo.value = campo.value.trim();
                if (campo.value === '') {
                    camposValidos = false;
                }
            });

            const departamento = formulario.querySelector('select[name="departamento_id"]');
            if (departamento && departamento.value === '') {
                camposValidos = false;
            }

            if (!camposValidos) {
                evento.preventDefault();
                alert('Complete todos los campos antes de continuar.');
                return;
            }

            const accionTexto = accion.value === 'crear_departamento'
                ? 'registrar el departamento'
                : 'registrar el empleado';

            if (!window.confirm('¿Desea ' + accionTexto + '?')) {
                evento.preventDefault();
            }
        });
    });
});