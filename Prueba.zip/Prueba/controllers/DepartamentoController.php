<?php
require_once __DIR__ . '/../models/Departamento.php';

class DepartamentoController
{
    public function index(): void
    {
        $mensaje = '';
        $error = '';
        $departamentos = [];
        $empleados = [];
        $departamentoSeleccionado = filter_input(INPUT_GET, 'departamento_id', FILTER_VALIDATE_INT) ?: 0;

        try {
            $modelo = new Departamento();

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $accion = $_POST['accion'] ?? '';

                if ($accion === 'crear_departamento') {
                    $nombre = trim($_POST['nombre_departamento'] ?? '');

                    if ($nombre === '') {
                        $error = 'Escriba el nombre del departamento.';
                    } else {
                        $modelo->crearDepartamento($nombre);
                        $mensaje = 'Departamento registrado correctamente.';
                    }
                } elseif ($accion === 'crear_empleado') {
                    $nombre = trim($_POST['nombre'] ?? '');
                    $apellido = trim($_POST['apellido'] ?? '');
                    $departamentoId = filter_var($_POST['departamento_id'] ?? '', FILTER_VALIDATE_INT);

                    if ($nombre === '' || $apellido === '') {
                        $error = 'Escriba el nombre y el apellido del empleado.';
                    } elseif (!$departamentoId || !$modelo->existeDepartamento((int) $departamentoId)) {
                        $error = 'Seleccione un departamento válido.';
                    } else {
                        $modelo->crearEmpleado($nombre, $apellido, (int) $departamentoId);
                        $mensaje = 'Empleado registrado correctamente.';
                    }
                }
            }

            $departamentos = $modelo->obtenerDepartamentos();

            if ($departamentoSeleccionado > 0) {
                $empleados = $modelo->buscarEmpleadosPorDepartamento($departamentoSeleccionado);
            }
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                $error = 'Ese departamento ya está registrado.';
            } else {
                $error = 'No se pudo acceder a la base de datos. Importe base_datos.sql y revise la conexión.';
            }
        }

        require __DIR__ . '/../views/departamentos.php';
    }
}