<?php
function escapar(string $texto): string
{
    return htmlspecialchars($texto, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Departamentos y empleados</title>
</head>
<body>
    <h1>Gestión de departamentos y empleados</h1>

    <?php if ($mensaje !== ''): ?>
        <p><?= escapar($mensaje) ?></p>
    <?php endif; ?>
    <?php if ($error !== ''): ?>
        <p><?= escapar($error) ?></p>
    <?php endif; ?>

    <h2>Registrar departamento</h2>
    <form method="post" action="index.php">
        <input type="hidden" name="accion" value="crear_departamento">
        <label for="nombre_departamento">Nombre del departamento:</label>
        <input type="text" id="nombre_departamento" name="nombre_departamento" maxlength="100" required>
        <button type="submit">Guardar departamento</button>
    </form>

    <h2>Registrar empleado</h2>
    <?php if (count($departamentos) === 0): ?>
        <p>Primero registre un departamento.</p>
    <?php else: ?>
        <form method="post" action="index.php">
            <input type="hidden" name="accion" value="crear_empleado">
            <p>
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" maxlength="100" required>
            </p>
            <p>
                <label for="apellido">Apellido:</label>
                <input type="text" id="apellido" name="apellido" maxlength="100" required>
            </p>
            <p>
                <label for="departamento_empleado">Departamento:</label>
                <select id="departamento_empleado" name="departamento_id" required>
                    <option value="">Seleccione un departamento</option>
                    <?php foreach ($departamentos as $departamento): ?>
                        <option value="<?= (int) $departamento['id'] ?>"><?= escapar($departamento['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>
            </p>
            <button type="submit">Guardar empleado</button>
        </form>
    <?php endif; ?>

    <h2>Buscar empleados por departamento</h2>
    <?php if (count($departamentos) > 0): ?>
        <form method="get" action="index.php">
            <label for="departamento_busqueda">Departamento:</label>
            <select id="departamento_busqueda" name="departamento_id" required>
                <option value="">Seleccione un departamento</option>
                <?php foreach ($departamentos as $departamento): ?>
                    <option value="<?= (int) $departamento['id'] ?>" <?= $departamentoSeleccionado === (int) $departamento['id'] ? 'selected' : '' ?>>
                        <?= escapar($departamento['nombre']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Buscar</button>
        </form>
    <?php endif; ?>

    <?php if ($departamentoSeleccionado > 0): ?>
        <h2>Empleados del departamento seleccionado</h2>
        <?php if (count($empleados) === 0): ?>
            <p>No hay empleados registrados en este departamento.</p>
        <?php else: ?>
            <table border="1">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Departamento</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($empleados as $empleado): ?>
                        <tr>
                            <td><?= escapar($empleado['nombre']) ?></td>
                            <td><?= escapar($empleado['apellido']) ?></td>
                            <td><?= escapar($empleado['departamento']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    <?php endif; ?>
    <script src="script.js"></script>
</body>
</html>