<?php
require_once __DIR__ . '/controllers/DepartamentoController.php';

$controlador = new DepartamentoController();
$controlador->index();